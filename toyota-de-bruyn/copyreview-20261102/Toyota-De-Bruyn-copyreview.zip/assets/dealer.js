'use strict';
// Eigen bedrijfsbron: locatiepagina Toyota De Bruyn, gecontroleerd 31-10-2026.
window.DEALER = Object.freeze({name:'Toyota De Bruyn Machelen',street:'Kerklaan 56',city:'1830 Machelen',phone:'02 251 81 28',tel:'+3222518128',email:'machelen@toyotadebruyn.be',showroom:'Maandag–vrijdag 07.30–18.00 · zaterdag 09.00–17.00',workshop:'Maandag–vrijdag 08.00–12.00 en 13.00–17.00',source:'https://www.toyotadebruyn.be/nl/about/machelen'});
// Beperkte modelselectie; geen complete catalogus, voorraad of prijslijst.
window.MODELS = Object.freeze([{id:'yaris-cross',name:'Yaris Cross',description:"Verhoogde zitpositie. Full hybrid zonder laadkabel."},{id:'c-hr-plus',name:'C-HR+',description:"Een uitgesproken coupélijn. Volledig elektrisch."},{id:'rav4',name:'RAV4',description:"Schoolrit, werkdag, weekend weg. Als hybrid of plug-in hybrid."}]);
// Modelnamen: Toyota België, bedrijfsvoertuigen, gecontroleerd 31-10-2026.
// https://nl.toyota.be/business/modellen/bedrijfsvoertuigen/diesel-benzine
window.VANS = Object.freeze([{id:'proace-city',name:'Proace City',description:'Ontdek het model en bespreek welke uitvoering bij je werk past.'},{id:'proace',name:'Proace',description:'Ontdek het model en bespreek welke uitvoering bij je werk past.'},{id:'proace-max',name:'Proace Max',description:'Ontdek het model en bespreek welke uitvoering bij je werk past.'}]);
